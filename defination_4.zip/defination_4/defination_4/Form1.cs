﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace defination_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                MessageBox.Show("You are selected red colour...");
                return;
            }

            else if (radioButton2.Checked == true)
            {
                MessageBox.Show("You are selected white colour...");
                return;
            }

            else if (radioButton3.Checked == true)
            {
                MessageBox.Show("You are selected black colour...");
                return;
            }

            else
            {
                MessageBox.Show("Please select colour!!!");
            }
        }
    }
}
